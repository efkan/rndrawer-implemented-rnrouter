'use strict';

let Colors = {
  tint: 'rgb(0, 122, 255)',
};

export default Colors;
