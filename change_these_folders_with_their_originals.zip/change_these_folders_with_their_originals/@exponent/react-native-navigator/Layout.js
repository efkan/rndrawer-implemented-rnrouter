'use strict';

import {
  PixelRatio,
} from 'react-native';

export default {
  pixel: 1 / PixelRatio.get(),
};
