export default function debug(msg){
    //console.log(msg);
}
