import React from 'react'

// schema class represents schema for routes and it is processed inside Router component
export class Schema extends React.Component {
    className(){
        return "Schema";
    }
    render(){
        return null;
    }
}

// route class processed inside Router component
export class Route extends React.Component {
    className(){
        return "Route";
    }
    render(){
        return null;
    }

}
