# cloneReferencedElement for React Native

This is a version of `React.cloneElement` that preserves the original element's ref even if you specify a new ref for the clone.
